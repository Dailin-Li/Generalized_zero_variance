Except for "BG_MC_MCMC.py" that is for MC & MCMC background, other files are to apply the 
generalized zero variance method to differnt combinations of Bayesian models and dataset.
 

refer to:

1. https://people.duke.edu/~ccc14/sta-663/PyStan.html

2. https://mc-stan.org/docs/2_18/stan-users-guide/logistic-probit-regression-section.html


dataset

1. MCMC example
2. Mira 2014